<div id='R' style='display:none;'></div>

<p style='font-size:7pt; color:gray;'>Actualmente trabaja esta aplicación en con una base de datos de prueba, en modo beta.</p>



<script>
    
function URLModal(id) {
var page = "apps/detalles.php?id="+id
var $dialog = $('#DivModal')
  .html('<iframe style="border: 0px; padding:0px; " src="' + page + '" width="100%" height="100%"></iframe>')  
} 

</script>


<div id='DivModal' class='modal' style='display:none;'></div>
</body> </html>

