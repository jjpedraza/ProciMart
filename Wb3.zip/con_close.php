<?php
// require_once("preference.php");

mysqli_close($LaConeccion);
unset($Con_Val);
unset($Con_Msg);
unset($Con_Tsql);
unset($Con_name);
unset($Con_pass);
unset($Con_user);
unset($Con_host);
unset($RConF);
unset($FPing);
unset($Con_Val);
unset($RCon);


?>