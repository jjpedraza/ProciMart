<?php
include("head.php");
include("header.php");
    // $val = "Fruta Mandarina";
    // $urlImg = PixaBay($val); 
    // echo $urlImg;
    // echo '<script>
    // $("body").css("background-image", "url('.$urlImg.')"); 
    // </script>';


    Bakcground("Fruta Naranja");


include("footer.php");
?>